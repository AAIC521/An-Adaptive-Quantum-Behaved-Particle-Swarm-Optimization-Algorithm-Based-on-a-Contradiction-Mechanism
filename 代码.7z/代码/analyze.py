import os
import matplotlib.pyplot as plt
import numpy as np
from testData_base import *
from testData_project import *
from testMain_base import get_parameter
from QPSO_algorithms import CQPSO
from EA_toolbox import *

function_names = [
    Sphere,
    Schwefel_226,
    Schwefel_222,
    Schwefel_12,
    Schwefel_221,
    Rosenbrock,
    Rastrigin,
    Ackley,
    Griewank,
    Penalized1,
    Penalized2,
]
project_function_names = [
    "spring_design",
    "three_bar_truss",
    "cantilever_beam_design",
    "welded_beam_design",
    "gear_train_design",
    "pressure_vessel_optimization",
    "speed_reducer_optimization",
    "I_beam_vertical_deflection_design",
    "corrugated_bulkhead_design",
    "tubular_column_design",
]

algorithm_names = [
    "QPSO",
    "CQPSO",
    "LQPSO",
    "QDQPSO",
    "eQPSO",
    "GQPSO",
    "IGQPSO",
    "QSPSO",
    "GDQPSO",
    "IQPSO",
]

base_func_test_data = np.array(
    [
        base_func_data_QPSO,
        base_func_data_CQPSO,
        base_func_data_LQPSO,
        base_func_data_QDQPSO,
        base_func_data_eQPSO,
        base_func_data_GQPSO,
        base_func_data_IGQPSO,
        base_func_data_QSPSO,
        base_func_data_GDQPSO,
        base_func_data_IQPSO,
    ]
)

project_func_test_data = np.array(
    [
        project_func_data_QPSO,
        project_func_data_CQPSO,
        project_func_data_LQPSO,
        project_func_data_QDQPSO,
        project_func_data_eQPSO,
        project_func_data_GQPSO,
        project_func_data_IGQPSO,
        project_func_data_QSPSO,
        project_func_data_GDQPSO,
        project_func_data_IQPSO,
    ]
)

project_func_data_CQPSO_solution = [
    np.array(project_func_data_CQPSO_solution[i])
    for i in range(len(project_func_data_CQPSO_solution))
]


def base_median_best_worst_std():
    for i in range(len(algorithm_names)):
        print(
            f"{algorithm_names[i]}: median:\n",
            np.median(base_func_test_data[i], axis=0),
        )
        print(f"{algorithm_names[i]}: best:\n", np.min(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(base_func_test_data[i], axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(base_func_test_data[i], axis=0))
        print("\n")


def project_median_best_worst_std():
    for i in range(len(algorithm_names)):
        data = project_func_test_data[i][:, np.array([0, 1, 2, 3, 4, 5, 6, 7, 9])]
        print(f"{algorithm_names[i]}: median:\n", np.median(data, axis=0))
        print(f"{algorithm_names[i]}: best:\n", np.min(data, axis=0))
        print(f"{algorithm_names[i]}: worst:\n", np.max(data, axis=0))
        print(f"{algorithm_names[i]}: std:\n", np.std(data, axis=0))
        print("\n")


# 定义绘制箱线图的函数
def plot_boxplot(data, title, x_labels, y_labels, save_path):
    # 创建箱体并设置样式
    fig, ax = plt.subplots()  # 创建一个图形及子图
    boxprops = dict(color="blue")  # 定义箱子的样式：边框颜色为蓝色，无填充
    medianprops = dict(
        color="red", linewidth=1
    )  # 定义中位数线的样式：颜色为红色，线宽为1
    whiskerprops = dict(
        color="black", linewidth=1.5, linestyle="--"
    )  # 定义须的样式：颜色为绿色，线宽为1.5，虚线
    flierprops = dict(
        marker="+", markerfacecolor="red", markeredgecolor="red", markersize=8
    )  # 定义异常值的样式

    # 绘制箱型图
    ax.boxplot(
        data,
        vert=True,
        patch_artist=False,  # 移除填充
        boxprops=boxprops,
        medianprops=medianprops,
        whiskerprops=whiskerprops,
        flierprops=flierprops,
    )

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei"]  # 设置全局字体为微软雅黑

    # 添加标签
    ax.set_title(title, fontsize=16)  # 设置标题及字体大小
    ax.set_ylabel(y_labels, fontsize=12)  # 设置 Y 轴标签及字体大小
    ax.set_xticklabels(
        x_labels, rotation=45, fontsize=10
    )  # 更改 X 轴标签，并旋转 45 度
    ax.grid(
        True, linestyle="-", linewidth=0.5, alpha=0.5
    )  # 显示网格线，样式为实线，线宽为0.5，透明度为0.5
    ax.set_yscale("log")
    # 保存图像
    # 将标题转换为文件名
    os.makedirs(save_path, exist_ok=True)
    filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
    plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")

    # 显示图形并继续执行代码
    plt.show(block=False)

    # 设置计时器在5秒后关闭窗口
    plt.pause(5)
    plt.close()


def plot_all_track_map(F=None):
    def plot_track_map(func, all_points, track, lb, ub, title, resolution=1000):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = []
        for i in x:
            for j in y:
                z.append(func(np.array([i, j])))
        z = np.array(z).reshape((resolution, resolution))

        plt.figure(figsize=(10, 10))

        # 绘制等高线
        plt.contour(x, y, z, levels=100, cmap="viridis")

        # 绘制所有点（在等高线之上）
        all_points = np.array(all_points)
        plt.scatter(
            all_points[:, 0],
            all_points[:, 1],
            color="black",
            label="All Points",
            zorder=5,
        )

        # 绘制轨迹（在等高线之上）
        track = np.array(track)
        plt.plot(
            track[:, 0], track[:, 1], color="red", linewidth=5, label="Track", zorder=10
        )

        # 添加标题和标签
        plt.title(title, fontsize=32)
        plt.legend(prop={"size": 20})
        plt.tick_params(axis="both", which="major", labelsize=20)

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")
        plt.show()

    if F == None:
        for func_index in range(len(function_names)):
            algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO, dim=2))
            result = algorithm.optimize()[-1]
            plot_track_map(
                function_names[func_index],
                result[0],
                result[1],
                get_lb_ub_dim(function_names[func_index], dim=2)[0],
                get_lb_ub_dim(function_names[func_index], dim=2)[1],
                f"F{func_index+1} track",
            )
    else:
        func_index = F - 1
        algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO, dim=2))
        result = algorithm.optimize()[-1]
        plot_track_map(
            function_names[func_index],
            result[0],
            result[1],
            get_lb_ub_dim(function_names[func_index], dim=2)[0],
            get_lb_ub_dim(function_names[func_index], dim=2)[1],
            f"F{func_index+1} track",
        )


def base_box():
    for func_index in range(len(function_names)):
        func_data = []
        for algorithm_index in range(len(algorithm_names)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    base_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"F{func_index+1} boxplot",
            algorithm_names,
            "fitness",
            "./figure/",
        )


def project_box():
    for func_index in range(len(project_function_names)):
        if func_index == 8:
            continue
        func_data = []
        for algorithm_index in range(len(algorithm_names)):
            algorithm_data = []
            for proccessing in range(100):
                algorithm_data.append(
                    project_func_test_data[algorithm_index][proccessing][func_index]
                )
            func_data.append(algorithm_data)
        plot_boxplot(
            func_data,
            f"{project_function_names[func_index]} boxplot",
            algorithm_names,
            "value",
            "./figure/",
        )


def CQPSO_project_functions_value():
    def spring_design(x):
        def g_1(x_1, x_2, x_3):
            return 1 - x_2**3 * x_3 / (71785 * x_1**4)

        def g_2(x_1, x_2):
            return (
                (4 * x_2**2 - x_1 * x_2) / (12566 * (x_2 * x_1**3 - x_1**4))
                + 1 / (5108 * x_1**2)
                - 1
            )

        def g_3(x_1, x_2, x_3):
            return 1 - 140.45 * x_1 / (x_2**2 * x_3)

        def g_4(x_1, x_2):
            return (x_1 + x_2) / 1.5 - 1

        def f(x_1, x_2, x_3):
            return (x_3 + 2) * x_2 * x_1**2

        x = np.clip(x, np.array([0.05, 0.25, 2]), np.array([2, 1.3, 15]))
        x_1, x_2, x_3 = x[0], x[1], x[2]
        print("--------------spring design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_1, x_2))
        print("g_3:", g_3(x_1, x_2, x_3))
        print("g_4:", g_4(x_1, x_2))
        print("f:", f(x_1, x_2, x_3))
        print("\n")

    def three_bar_truss(x):
        def g_1(x_1, x_2):
            return (
                2 * (2**0.5 * x_1 + x_2) * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) - 2
            )

        def g_2(x_1, x_2):
            return 2 * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) * x_2 - 2

        def g_3(x_1, x_2):
            return 2 * (x_1 + 2**0.5 * x_2) ** (-1) - 2

        def f(x_1, x_2):
            return (2 ** (3 / 2) * x_1 + x_2) * 100

        x = np.clip(x, np.array([1e-9, 1e-9]), np.array([1, 1]))
        x_1, x_2 = x[0], x[1]
        print("--------------three bar truss--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("g_1:", g_1(x_1, x_2))
        print("g_2:", g_2(x_1, x_2))
        print("g_3:", g_3(x_1, x_2))
        print("f:", f(x_1, x_2))
        print("\n")

    def cantilever_beam_design(x):
        def g_1(x_1, x_2, x_3, x_4, x_5):
            return 61 / x_1**3 + 37 / x_2**3 + 19 / x_3**3 + 7 / x_4**3 + 1 / x_5**3 - 1

        def f(x_1, x_2, x_3, x_4, x_5):
            return 0.0624 * (x_1 + x_2 + x_3 + x_4 + x_5)

        x = np.clip(
            x,
            np.array([0.01, 0.01, 0.01, 0.01, 0.01]),
            np.array([100, 100, 100, 100, 100]),
        )
        x_1, x_2, x_3, x_4, x_5 = x[0], x[1], x[2], x[3], x[4]
        print("--------------cantilever beam design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("x_5:", x_5)
        print("g_1:", g_1(x_1, x_2, x_3, x_4, x_5))
        print("f:", f(x_1, x_2, x_3, x_4, x_5))
        print("\n")

    def welded_beam_design(x):
        sigma_max = 30000
        E = 30 * 1e6
        t_max = 13000
        L = 14
        P = 6000
        delta_max = 0.25
        G = 12 * 1e6

        def M(x_2):
            return (L + x_2 / 2) * P

        def R(x_1, x_2, x_3):
            return (x_2**2 / 4 + ((x_1 + x_3) / 2) ** 2) ** 0.5

        def delta(x_3, x_4):
            return 4 * P * L**3 / (E * x_3**3 * x_4)

        def J(x_1, x_2, x_3):
            return (x_2**2 / 12 + ((x_1 + x_3) / 2) ** 2) * x_1 * x_2 * 2 ** (3 / 2)

        def sigma(x_3, x_4):
            return 6 * P * L / (x_4 * x_3**2)

        def P_c(x_3, x_4):
            return (
                4.013
                * E
                * x_4**3
                * x_3
                / (6 * L**2)
                * (1 - x_3 / (2 * L) * (E / (4 * G)) ** 0.5)
            )

        def t_1(x_1, x_2):
            return P / (2**0.5 * x_1 * x_2)

        def t_2(x_1, x_2, x_3):
            return R(x_1, x_2, x_3) * M(x_2) / J(x_1, x_2, x_3)

        def t(x_1, x_2, x_3):
            return (
                t_1(x_1, x_2) ** 2
                + 2 * t_1(x_1, x_2) * t_2(x_1, x_2, x_3) * x_2 / (2 * R(x_1, x_2, x_3))
                + t_2(x_1, x_2, x_3) ** 2
            ) ** 0.5

        def g_1(x_1, x_2, x_3):
            return t(x_1, x_2, x_3) - t_max

        def g_2(x_3, x_4):
            return -sigma_max + sigma(x_3, x_4)

        def g_3(x_1, x_4):
            return x_1 - x_4

        def g_4(x_1, x_2, x_3, x_4):
            return 0.04811 * x_3 * x_4 * (14 + x_2) + 0.10471 * x_1**2 - 5

        def g_5(x_1):
            return -x_1 + 0.125

        def g_6(x_3, x_4):
            return delta(x_3, x_4) - delta_max

        def g_7(x_3, x_4):
            return P - P_c(x_3, x_4)

        def f(x_1, x_2, x_3, x_4):
            return 1.10471 * x_2 * x_1**2 + 0.04811 * x_3 * x_4 * (14 + x_2)

        x = np.clip(
            x,
            np.array([0.1, 0.1, 0.1, 0.1]),
            np.array([2, 10, 10, 2]),
        )
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------welded beam design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_3, x_4))
        print("g_3:", g_3(x_1, x_4))
        print("g_4:", g_4(x_1, x_2, x_3, x_4))
        print("g_5:", g_5(x_1))
        print("g_6:", g_6(x_3, x_4))
        print("g_7:", g_7(x_3, x_4))
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def gear_train_design(x):
        def f(x_1, x_2, x_3, x_4):
            return (1 / 6.931 - x_2 * x_3 / (x_1 * x_4)) ** 2

        x = np.round(np.clip(x, np.array([12, 12, 12, 12]), np.array([60, 60, 60, 60])))
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------gear train design--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def pressure_vessel_optimization(x):
        def g_1(x_1, x_3):
            return -x_1 + 0.0193 * x_3

        def g_2(x_2, x_3):
            return -x_2 + 0.00954 * x_3

        def g_3(x_3, x_4):
            return 1296000 - np.pi * x_3**2 * x_4 - 4 * np.pi / 3 * x_3**3

        def g_4(x_4):
            return x_4 - 240

        def f(x_1, x_2, x_3, x_4):
            return (
                19.84 * x_1**2 * x_3
                + 3.1661 * x_1**2 * x_4
                + 1.7781 * x_2 * x_3**2
                + 0.6224 * x_1 * x_3 * x_4
            )

        x = np.clip(x, np.array([1e-9, 1e-9, 10, 10]), np.array([100, 100, 200, 200]))
        x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
        print("--------------pressure vessel optimization--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("g_1:", g_1(x_1, x_3))
        print("g_2:", g_2(x_2, x_3))
        print("g_3:", g_3(x_3, x_4))
        print("g_4:", g_4(x_4))
        print("f:", f(x_1, x_2, x_3, x_4))
        print("\n")

    def speed_reducer_optimization(x):
        def g_1(x_1, x_2, x_3):
            return -1 + 27 / (x_1 * x_2**2 * x_3)

        def g_2(x_1, x_2, x_3):
            return -1 + 397.5 / (x_1 * x_2**2 * x_3**2)

        def g_3(x_2, x_3, x_4, x_6):
            return -1 + 1.93 * x_4**3 / (x_2 * x_3 * x_6**4)

        def g_4(x_2, x_3, x_5, x_7):
            return -1 + 1.93 * x_5**3 / (x_2 * x_3 * x_7**4)

        def g_5(x_2, x_3, x_4, x_6):
            return ((745 * x_4 / (x_2 * x_3)) ** 2 + 16.9 * 1e6) ** 0.5 / (
                110 * x_6**3
            ) - 1

        def g_6(x_2, x_3, x_5, x_7):
            return ((745 * x_5 / (x_2 * x_3)) ** 2 + 157.5 * 1e6) ** 0.5 / (
                85 * x_7**3
            ) - 1

        def g_7(x_2, x_3):
            return -1 + x_2 * x_3 / 40

        def g_8(x_1, x_2):
            return -1 + 5 * x_2 / x_1

        def g_9(x_1, x_2):
            return -1 + x_1 / (12 * x_2)

        def g_10(x_4, x_6):
            return -1 + (1.5 * x_6 + 1.9) / x_4

        def g_11(x_5, x_7):
            return -1 + (1.1 * x_7 + 1.9) / x_5

        def f(x_1, x_2, x_3, x_4, x_5, x_6, x_7):
            return (
                0.7854 * x_1 * x_2**2 * (3.3333 * x_3**2 + 14.9334 * x_3 - 43.0934)
                - 1.5079 * x_1 * (x_6**2 + x_7**2)
                + 7.4777 * (x_6**3 + x_7**3)
                + 0.7854 * (x_4 * x_6**2 + x_5 * x_7**2)
            )

        x = np.clip(
            x,
            np.array([2.6, 0.7, 17, 7.3, 7.8, 2.9, 5]),
            np.array([3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5]),
        )
        x_1, x_2, x_3, x_4, x_5, x_6, x_7 = x[0], x[1], x[2], x[3], x[4], x[5], x[6]
        print("--------------speed reducer optimization--------------")
        print("x_1:", x_1)
        print("x_2:", x_2)
        print("x_3:", x_3)
        print("x_4:", x_4)
        print("x_5:", x_5)
        print("x_6:", x_6)
        print("x_7:", x_7)
        print("g_1:", g_1(x_1, x_2, x_3))
        print("g_2:", g_2(x_1, x_2, x_3))
        print("g_3:", g_3(x_2, x_3, x_4, x_6))
        print("g_4:", g_4(x_2, x_3, x_5, x_7))
        print("g_5:", g_5(x_2, x_3, x_4, x_6))
        print("g_6:", g_6(x_2, x_3, x_5, x_7))
        print("g_7:", g_7(x_2, x_3))
        print("g_8:", g_8(x_1, x_2))
        print("g_9:", g_9(x_1, x_2))
        print("g_10:", g_10(x_4, x_6))
        print("g_11:", g_11(x_5, x_7))
        print("f:", f(x_1, x_2, x_3, x_4, x_5, x_6, x_7))
        print("\n")

    def I_beam_vertical_deflection_design(x):
        def g_1(h, b, t_w, t_f):
            return t_w * (h - 2 * t_f) + 2 * b * t_f - 300

        def g_2(h, b, t_w, t_f):
            x_1 = (
                2 * b * t_f * (4 * t_f**2 - 3 * h * (h - 2 * t_f))
                + t_w * (h - 2 * t_f) ** 3
            )
            x_2 = 2 * t_f * b**3 + (h - 2 * t_f) * t_w**3
            return 18 * h * 1e4 / x_1 + 15 * b * 1e3 / x_2

        def f(h, b, t_w, t_f):
            return 5000 / (
                t_w * (h - 2 * t_f) ** 3 / 12
                + b * t_f**3 / 6
                + 2 * b * t_f * (h - t_f) ** 2 / 4
            )

        x = np.clip(x, np.array([10, 10, 0.9, 0.9]), np.array([80, 50, 5, 5]))
        h, b, t_w, t_f = x[0], x[1], x[2], x[3]
        print("--------------I beam vertical deflection design--------------")
        print("h:", h)
        print("b:", b)
        print("t_w:", t_w)
        print("t_f:", t_f)
        print("g_1:", g_1(h, b, t_w, t_f))
        print("g_2:", g_2(h, b, t_w, t_f))
        print("f:", f(h, b, t_w, t_f))
        print("\n")

    def tubular_column_design(x):
        P, sigma_y, p, L, E = 2500, 500, 0.0025, 250, 8.5 * 1e5

        def g_1(d, t):
            return P / (np.pi * d * t * sigma_y) - 1

        def g_2(d, t):
            return 8 * P / (np.pi**3 * E * d * t * (d**2 + t**2)) - 1

        def g_3(d):
            return 2 / d - 1

        def g_4(d):
            return d / 14 - 1

        def g_5(t):
            return 1 / (5 * t) - 1

        def g_6(t):
            return 5 * t / 4 - 1

        def f(d, t):
            return 9.8 * d * t + 2 * d

        x = np.clip(x, np.array([2, 0.2]), np.array([14, 0.8]))
        d, t = x[0], x[1]
        print("--------------tubular column design--------------")
        print("d:", d)
        print("t:", t)
        print("g_1:", g_1(d, t))
        print("g_2:", g_2(d, t))
        print("g_3:", g_3(d))
        print("g_4:", g_4(d))
        print("g_5:", g_5(t))
        print("g_6:", g_6(t))
        print("f:", f(d, t))
        print("\n")

    spring_design(project_func_data_CQPSO_solution[0])
    three_bar_truss(project_func_data_CQPSO_solution[1])
    cantilever_beam_design(project_func_data_CQPSO_solution[2])
    welded_beam_design(project_func_data_CQPSO_solution[3])
    gear_train_design(project_func_data_CQPSO_solution[4])
    pressure_vessel_optimization(project_func_data_CQPSO_solution[5])
    speed_reducer_optimization(project_func_data_CQPSO_solution[6])
    I_beam_vertical_deflection_design(project_func_data_CQPSO_solution[7])
    tubular_column_design(project_func_data_CQPSO_solution[9])


def plot_all_optimization_curve(F=None):
    if F == None:
        for func_index in range(len(function_names)):
            algorithm = CQPSO(*get_parameter(function_names[func_index], CQPSO))
            algorithm.optimize()
            algorithm.plot_best(
                title=f"F{func_index+1} optimization curve", save_path="./figure/"
            )
    else:
        algorithm = CQPSO(*get_parameter(function_names[F - 1], CQPSO))
        algorithm.optimize()
        algorithm.plot_best(title=f"F{F} optimization curve", save_path="./figure/")


def plot_all_function_3D(F=None):
    def plot_function_3D(func, lb, ub, title, resolution=100):
        x = np.linspace(lb[0], ub[0], resolution)
        y = np.linspace(lb[1], ub[1], resolution)
        z = np.zeros((resolution, resolution))
        for i in range(resolution):
            for j in range(resolution):
                z[i, j] = func(np.array([x[i], y[j]]))

        fig = plt.figure(figsize=(10, 10))
        ax = fig.add_subplot(111, projection="3d")

        # 绘制3D曲面
        X, Y = np.meshgrid(x, y)
        ax.plot_surface(
            X, Y, z, cmap="viridis", alpha=0.8, rstride=1, cstride=1, edgecolor="none"
        )

        # 添加标题
        ax.set_title(title, fontsize=32)

        # 设置刻度线但不显示刻度值
        # ax.xaxis.set_major_formatter(plt.NullFormatter())
        # ax.yaxis.set_major_formatter(plt.NullFormatter())
        # ax.zaxis.set_major_formatter(plt.NullFormatter())

        save_path = "./figure/"
        os.makedirs(save_path, exist_ok=True)
        filename = os.path.join(save_path, title.replace(" ", "_") + ".svg")
        plt.savefig(filename, format="svg", dpi=2560, bbox_inches="tight")
        plt.show()

    if F == None:
        for func_index in range(len(function_names)):
            plot_function_3D(
                function_names[func_index],
                get_lb_ub_dim(function_names[func_index], dim=2)[0],
                get_lb_ub_dim(function_names[func_index], dim=2)[1],
                f"F{func_index+1} 3D",
            )
    else:
        plot_function_3D(
            function_names[F - 1],
            get_lb_ub_dim(function_names[F - 1], dim=2)[0],
            get_lb_ub_dim(function_names[F - 1], dim=2)[1],
            f"F{F} 3D",
        )


if "__main__" == __name__:
    # 可调用的函数
    # base_median_best_worst_std()
    base_box()
    # plot_all_track_map(F=6)
    # plot_all_optimization_curve()
    # plot_all_function_3D()

    # project_median_best_worst_std()
    # CQPSO_project_functions_value()
    # project_box()
