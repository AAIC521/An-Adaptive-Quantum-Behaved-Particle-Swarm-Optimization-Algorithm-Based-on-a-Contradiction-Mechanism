import numpy as np
from EA_toolbox import *


class QDQPSO:
    def __init__(
        self, func, init_function, dim, size, iter_num, lb, ub, is_print, a, lamda
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.a = a
        self.lamda = lamda

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X = np.concatenate((self.X, self.quasi_OB_learning()), axis=0)
        self.X_score = np.array([self.func(self.X[i]) for i in range(self.X.shape[0])])
        best_index = np.argsort(self.X_score)[: self.size]
        self.X = self.X[best_index]
        self.X_score = self.X_score[best_index]
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]
        self.diversity_history = []

        self.a_1 = 0.9
        self.a_2 = 0.4

    def quasi_OB_learning(self):
        X_r = self.ub + self.lb - self.X
        random_factor = np.random.rand(self.size, self.dim)
        X_qr = (1 - random_factor) * X_r + random_factor * (self.ub + self.lb) / 2
        return X_qr

    def Bound_constraint(self, individual):
        def calculate_y(rand_num):
            if rand_num < 0.5:
                return 1
            return 1 / rand_num - 1

        for j in range(self.dim):
            if individual[j] < self.lb[j]:
                y = calculate_y(np.random.rand())
                individual[j] = self.lb[j] + y * (self.ub[j] - self.lb[j])
            elif individual[j] > self.ub[j]:
                y = calculate_y(np.random.rand())
                individual[j] = self.ub[j] - y * (self.ub[j] - self.lb[j])

        return individual

    def method_1(self, t, i):
        # ������ʷ���ž�ֵ
        average_p = np.sum(self.P, axis=0) / self.size
        # �������
        a = (self.a_1 - self.a_2) * (self.iter_num - t) / self.iter_num
        # ����������λ��
        p = a * self.P[i] + (1 - a) * self.gbest
        # ���������˶�
        random_factor_log = np.random.rand(self.dim)
        random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
        new_X = p + np.sign(random_factor_sign) * np.random.rand(self.dim) * np.abs(
            average_p - self.X[i]
        ) * np.log(random_factor_log)

        return self.Bound_constraint(new_X)

    def method_2(self, i):
        # ������ʷ���ž�ֵ
        average_p = np.sum(self.P, axis=0) / self.size
        # ����������λ��
        p = np.random.rand(self.dim) * self.P[i] + self.a * self.gbest
        # ���������˶�
        random_factor_log = np.random.rand(self.dim)
        random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
        new_X = p + np.sign(random_factor_sign) * np.random.rand(self.dim) * np.abs(
            average_p - self.X[i]
        ) * np.log(random_factor_log)

        return self.Bound_constraint(new_X)

    def diversity(self):
        return np.sum(
            np.sqrt(np.sum((self.X - np.mean(self.X, axis=0)) ** 2, axis=1))
        ) / (self.size * np.sqrt(np.sum((self.ub - self.lb) ** 2)))

    def optimize(self):
        for t in range(self.iter_num):
            for i in range(self.size):
                new_X_1 = self.method_1(t, i)
                new_X_2 = self.method_2(i)
                new_X_score_1 = self.func(new_X_1)
                new_X_score_2 = self.func(new_X_2)
                if new_X_score_1 < new_X_score_2:
                    self.X[i] = new_X_1
                    self.X_score[i] = new_X_score_1
                else:
                    self.X[i] = new_X_2
                    self.X_score[i] = new_X_score_2
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i]
                    self.P_score[i] = self.X_score[i]
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i]
                        self.gbest_score = self.P_score[i]

            if self.diversity() < self.lamda:
                rand_num = np.random.rand()
                new_gbest = (1 - rand_num) * self.gbest + rand_num * (
                    self.gbest - self.X[np.random.choice(self.size)]
                )
                new_gbest_score = self.func(new_gbest)
                if new_gbest_score < self.gbest_score:
                    self.gbest = new_gbest
                    self.gbest_score = new_gbest_score

            self.gbest_scores.append(self.gbest_score)
            self.diversity_history.append(diversity(self.P, self.lb, self.ub))
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )

