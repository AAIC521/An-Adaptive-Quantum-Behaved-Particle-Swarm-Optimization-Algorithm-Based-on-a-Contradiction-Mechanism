import numpy as np
from EA_toolbox import *


class IGQPSO:
    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_print,
        beta,
        sigma_0,
        sigma_1,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.beta = beta
        self.sigma_0 = sigma_0
        self.sigma_1 = sigma_1

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

    def calculate_weight(self):
        def ED(indiv_1, indiv_2):
            return np.sum((indiv_1 - indiv_2) ** 2) ** 0.5

        weight = np.array([[ED(self.P[i], self.gbest) for i in range(self.size)]])

        return weight / np.sum(weight)

    def optimize(self):
        for t in range(self.iter_num):
            sigma = (
                self.sigma_1
                + (self.sigma_0 - self.sigma_1) * (self.iter_num - t) / self.iter_num
            )
            weight = self.calculate_weight()
            # ������ʷ���ž�ֵ
            average_p = np.dot(weight, self.P)[0]
            # ���ӽ����˶�
            for i in range(self.size):
                # ����������λ��
                random_factor = np.random.rand(self.dim)
                p = random_factor * self.P[i] + (1 - random_factor) * self.gbest
                # ���������˶�
                random_factor_log = np.abs(np.random.normal(0, sigma, self.dim))
                random_factor_sign = np.random.uniform(low=-1, high=1, size=self.dim)
                new_X = p + np.sign(random_factor_sign) * self.beta * np.abs(
                    average_p - self.X[i]
                ) * np.log(random_factor_log)
                # ���½������ڷ�Χ��
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # ���µ�ǰ��Ⱥ
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # ���¸�������
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # ����ȫ������
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
