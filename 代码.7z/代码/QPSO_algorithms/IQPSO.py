import numpy as np
from EA_toolbox import *


class IQPSO:

    def __init__(
        self,
        func,
        init_function,
        dim,
        size,
        iter_num,
        lb,
        ub,
        is_print,
        alpha,
        beta_1,
        beta_2,
        miu,
        rou,
    ):
        self.func = func
        self.dim = dim
        self.size = size
        self.iter_num = iter_num
        self.lb = lb
        self.ub = ub
        self.is_print = is_print
        self.alpha = alpha
        self.beta_1 = beta_1
        self.beta_2 = beta_2
        self.miu = miu
        self.rou = rou

        self.X = init_function(self.lb, self.ub, self.dim, self.size)
        self.X_score = np.array([func(self.X[i]) for i in range(len(self.X))])
        self.P = self.X.copy()
        self.P_score = self.X_score.copy()
        self.gbest = self.X[np.argmin(self.X_score)].copy()
        self.gbest_score = np.min(self.X_score)
        self.gbest_scores = [self.gbest_score]

    def optimize(self):
        for t in range(self.iter_num):
            beta = (
                (self.beta_1 - self.beta_2) * (t / self.iter_num) ** 2
                + (self.beta_2 - self.beta_1) * 2 * t / self.iter_num
                + self.beta_1
            )
            # ������ʷ���ž�ֵ
            average_p = np.sum(self.P, axis=0) / self.size
            # ���ӽ����˶�
            for i in range(self.size):
                # ����������λ��
                random_factor = np.random.rand(self.dim)
                p = random_factor * self.P[i] + (1 - random_factor) * self.gbest
                # ���������˶�
                random_factor_log = np.random.rand(self.dim)
                # ����0.5
                index_big_5 = np.where(random_factor_log > 0.5)[0]
                new_X = np.zeros(self.dim)
                new_X[index_big_5] = (
                    p[index_big_5]
                    - self.alpha
                    * np.abs(p[index_big_5] - self.X[i, index_big_5])
                    * np.log(random_factor_log[index_big_5])
                    + beta
                    * np.abs(average_p[index_big_5] - self.X[i, index_big_5])
                    * np.random.standard_normal()
                )
                # С��0.5
                index_small_5 = np.where(random_factor_log < 0.5)[0]
                random_factor_sign = np.random.uniform(
                    low=-1, high=1, size=len(index_small_5)
                )
                new_X[index_small_5] = p[index_small_5] + np.sign(
                    random_factor_sign
                ) * beta * np.abs(
                    average_p[index_small_5] - self.X[i, index_small_5]
                ) * np.log(
                    random_factor_log[index_small_5]
                )

                # ���½������ڷ�Χ��
                new_X = np.clip(new_X, self.lb, self.ub)
                new_score = self.func(new_X)
                # ���µ�ǰ��Ⱥ
                self.X[i] = new_X.copy()
                self.X_score[i] = new_score.copy()
                # ���¸�������
                if self.X_score[i] < self.P_score[i]:
                    self.P[i] = self.X[i].copy()
                    self.P_score[i] = self.X_score[i].copy()
                    # ����ȫ������
                    if self.P_score[i] < self.gbest_score:
                        self.gbest = self.P[i].copy()
                        self.gbest_score = self.P_score[i].copy()
            # ���������
            average_f = np.mean(self.X_score)
            if np.max(np.abs(self.X_score - average_f)) > 1:
                f = np.max(np.abs(self.X_score - average_f))
            else:
                f = 1
            diversity = np.sum((self.X_score - average_f)) / f
            if diversity < self.miu:
                worst_index = np.argsort(self.X_score)[int(self.size * self.rou) :]
                self.X[worst_index] = np.random.uniform(
                    self.lb, self.ub, (len(worst_index), self.dim)
                )
                self.X_score[worst_index] = np.array(
                    [self.func(self.X[i]) for i in worst_index]
                )
                self.P[worst_index] = self.X[worst_index].copy()
                self.P_score[worst_index] = self.X_score[worst_index].copy()

            self.gbest_scores.append(self.gbest_score)
            if self.is_print:
                print(f"iter:{t}/{self.iter_num}, fitness:{self.gbest_scores[-1]}")

        return (
            self.gbest,
            self.gbest_score,
            self.gbest_scores,
        )
