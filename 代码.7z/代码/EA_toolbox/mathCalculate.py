import numpy as np


# 计算种群多样性
def diversity(Pop, lb, ub):
    return np.sum(np.sqrt(np.sum((Pop - np.mean(Pop, axis=0)) ** 2, axis=1))) / (
        Pop.shape[0] * np.sqrt(np.sum((ub - lb) ** 2))
    )


def split_into_chunks(total, chunk_size):
    chunks = [chunk_size for _ in range(total // chunk_size)]
    remainder = total % chunk_size
    if remainder:
        chunks.append(remainder)
    return chunks


# 广义平均数
def lehmer_mean(num, p):
    num = np.array(num)

    return np.sum(num**p) / np.sum(num ** (p - 1))
