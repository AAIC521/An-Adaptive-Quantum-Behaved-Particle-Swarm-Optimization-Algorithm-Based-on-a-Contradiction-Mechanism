import numpy as np


def get_lb_ub_dim(func, dim=100):
    if func == Sphere:
        return -100 * np.ones(dim), 100 * np.ones(dim), dim
    if func == Schwefel_226:
        return -500 * np.ones(dim), 500 * np.ones(dim), dim
    if func == Schwefel_222:
        return -100 * np.ones(dim), 100 * np.ones(dim), dim
    if func == Schwefel_12:
        return -100 * np.ones(dim), 100 * np.ones(dim), dim
    if func == Schwefel_221:
        return -100 * np.ones(dim), 100 * np.ones(dim), dim
    if func == Rosenbrock:
        return -30 * np.ones(dim), 30 * np.ones(dim), dim
    if func == Rastrigin:
        return -5.12 * np.ones(dim), 5.12 * np.ones(dim), dim
    if func == Ackley:
        return -32 * np.ones(dim), 32 * np.ones(dim), dim
    if func == Griewank:
        return -600 * np.ones(dim), 600 * np.ones(dim), dim
    if func == Penalized1:
        return -50 * np.ones(dim), 50 * np.ones(dim), dim
    if func == Penalized2:
        return -50 * np.ones(dim), 50 * np.ones(dim), dim
    if func == spring_design:
        return np.array([0.05, 0.25, 2]), np.array([2, 1.3, 15]), 3
    if func == three_bar_truss:
        return np.array([1e-9, 1e-9]), np.array([1, 1]), 2
    if func == cantilever_beam_design:
        return (
            np.array([0.01, 0.01, 0.01, 0.01, 0.01]),
            np.array([100, 100, 100, 100, 100]),
            5,
        )
    if func == welded_beam_design:
        return (
            np.array([0.1, 0.1, 0.1, 0.1]),
            np.array([2, 10, 10, 2]),
            4,
        )
    if func == gear_train_design:
        return np.array([12, 12, 12, 12]), np.array([60, 60, 60, 60]), 4
    if func == pressure_vessel_optimization:
        return np.array([1e-9, 1e-9, 10, 10]), np.array([100, 100, 200, 200]), 4
    if func == speed_reducer_optimization:
        return (
            np.array([2.6, 0.7, 17, 7.3, 7.8, 2.9, 5]),
            np.array([3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5]),
            7,
        )
    if func == I_beam_vertical_deflection_design:
        return np.array([10, 10, 0.9, 0.9]), np.array([80, 50, 5, 5]), 4

    if func == tubular_column_design:
        return np.array([2, 0.2]), np.array([14, 0.8]), 2


def Sphere(x):
    """
    范围：[-100, 100]
    最小值点：0
    最小值：0
    """
    x = x + 50
    return np.sum(x**2)


def Schwefel_226(x):
    """
    范围：[-500, 500]
    最小值点：420.96874636
    最小值：0
    """
    x = x - 250
    n = len(x)
    constant = 418.982887272433799807913601398
    return constant * n - sum(x * np.sin(np.sqrt(np.abs(x))))


def Schwefel_222(x):
    """
    范围：[-100, 100]
    最小值点：0
    最小值：0
    """
    x = x + 50
    sum_abs = np.sum(np.abs(x))
    prod_abs = np.prod(np.abs(x))
    return sum_abs + prod_abs


def Schwefel_12(x):
    """
    范围：[-100, 100]
    最小值点：0
    最小值：0
    """
    x = x - 50
    sum_squared = 0.0
    for i in range(len(x)):
        sum_squared += np.sum(x[: i + 1]) ** 2
    return sum_squared


def Schwefel_221(x):
    """
    范围：[-100, 100]
    最小值点：0
    最小值：0
    """
    x = x - 50
    return np.max(np.abs(x))


def Rosenbrock(x):
    """
    范围：[-30, 30]
    最小值点：1
    最小值：0
    """
    x = x + 10
    return np.sum(100 * (x[1:] - x[:-1] ** 2) ** 2 + (1 - x[:-1]) ** 2)


def Rastrigin(x):
    """
    范围：[-5.12, 5.12]
    最小值点：0
    最小值：0
    """
    x = x - 5.12 * 2 / 4
    n = len(x)
    A = 10
    return A * n + np.sum(x**2 - A * np.cos(2 * np.pi * x))


def Ackley(x):
    """
    范围：[-32, 32]
    最小值点：0
    最小值：0
    """
    x = x + 32 * 2 / 4
    a = 20
    b = 0.2
    c = 2 * np.pi
    n = len(x)

    sum1 = np.sum(x**2)
    sum2 = np.sum(np.cos(c * x))

    term1 = -a * np.exp(-b * np.sqrt(sum1 / n))
    term2 = -np.exp(sum2 / n)

    return term1 + term2 + a + np.exp(1)


def Griewank(x):
    """
    范围：[-600, 600]
    最小值点：0
    最小值：0
    """
    x = x + 600 * 2 / 4
    sum_term = np.sum(x**2) / 4000
    prod_term = np.prod(np.cos(x / np.sqrt(np.arange(1, len(x) + 1))))
    return sum_term - prod_term + 1


def Penalized1(x):
    """
    范围：[-50, 50]
    最小值点：-1
    最小值：0
    """
    x = x + 25

    def u(xi, a=10, k=100, m=4):
        if xi > a:
            return k * (xi - a) ** m
        elif xi < -a:
            return k * (-xi - a) ** m
        else:
            return 0

    n = len(x)
    y = 1 + (x + 1) / 4
    sum_u = np.sum([u(xi) for xi in x])

    term1 = 10 * np.sin(np.pi * y[0]) ** 2
    term2 = np.sum((y[:-1] - 1) ** 2 * (1 + 10 * np.sin(np.pi * y[1:]) ** 2))
    term3 = (y[-1] - 1) ** 2 * (1 + np.sin(2 * np.pi * y[-1]) ** 2)

    return (np.pi / n) * (term1 + term2 + term3) + sum_u


def Penalized2(x):
    """
    范围：[-50, 50]
    最小值点：1
    最小值：0
    """
    x = x - 25

    def u(xi, a=10, k=100, m=4):
        if xi > a:
            return k * (xi - a) ** m
        elif xi < -a:
            return k * (-xi - a) ** m
        else:
            return 0

    term1 = 0.1 * np.sin(3 * np.pi * x[0]) ** 2
    term2 = np.sum((x[:-1] - 1) ** 2 * (1 + np.sin(3 * np.pi * x[1:]) ** 2))
    term3 = (x[-1] - 1) ** 2 * (1 + np.sin(2 * np.pi * x[-1]) ** 2)
    sum_u = np.sum([u(xi) for xi in x])

    return term1 + term2 + term3 + 0.1 * np.sin(2 * np.pi * x[-1]) ** 2 + sum_u


def spring_design(x):
    def g_1(x_1, x_2, x_3):
        return 1 - x_2**3 * x_3 / (71785 * x_1**4)

    def g_2(x_1, x_2):
        return (
            (4 * x_2**2 - x_1 * x_2) / (12566 * (x_2 * x_1**3 - x_1**4))
            + 1 / (5108 * x_1**2)
            - 1
        )

    def g_3(x_1, x_2, x_3):
        return 1 - 140.45 * x_1 / (x_2**2 * x_3)

    def g_4(x_1, x_2):
        return (x_1 + x_2) / 1.5 - 1

    def f(x_1, x_2, x_3):
        return (x_3 + 2) * x_2 * x_1**2

    x = np.clip(x, np.array([0.05, 0.25, 2]), np.array([2, 1.3, 15]))
    x_1, x_2, x_3 = x[0], x[1], x[2]
    l = [1500000, 2000000, 200000, 10000]
    fitness = (
        f(x_1, x_2, x_3)
        + l[0] * np.max([0, g_1(x_1, x_2, x_3)])
        + l[1] * np.max([0, g_2(x_1, x_2)])
        + l[2] * np.max([0, g_3(x_1, x_2, x_3)])
        + l[3] * np.max([0, g_4(x_1, x_2)])
    )
    return fitness


def three_bar_truss(x):
    def g_1(x_1, x_2):
        return 2 * (2**0.5 * x_1 + x_2) * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) - 2

    def g_2(x_1, x_2):
        return 2 * (2 * x_1 * x_2 + 2**0.5 * x_1**2) ** (-1) * x_2 - 2

    def g_3(x_1, x_2):
        return 2 * (x_1 + 2**0.5 * x_2) ** (-1) - 2

    def f(x_1, x_2):
        return (2 ** (3 / 2) * x_1 + x_2) * 100

    x = np.clip(x, np.array([1e-9, 1e-9]), np.array([1, 1]))
    x_1, x_2 = x[0], x[1]
    l = [1500000, 2000000, 200000]
    fitness = (
        f(x_1, x_2)
        + l[0] * np.max([0, g_1(x_1, x_2)])
        + l[1] * np.max([0, g_2(x_1, x_2)])
        + l[2] * np.max([0, g_3(x_1, x_2)])
    )
    return fitness


def cantilever_beam_design(x):
    def g_1(x_1, x_2, x_3, x_4, x_5):
        return 61 / x_1**3 + 37 / x_2**3 + 19 / x_3**3 + 7 / x_4**3 + 1 / x_5**3 - 1

    def f(x_1, x_2, x_3, x_4, x_5):
        return 0.0624 * (x_1 + x_2 + x_3 + x_4 + x_5)

    x = np.clip(
        x,
        np.array([0.01, 0.01, 0.01, 0.01, 0.01]),
        np.array([100, 100, 100, 100, 100]),
    )
    x_1, x_2, x_3, x_4, x_5 = x[0], x[1], x[2], x[3], x[4]
    l = [1500000]

    fitness = f(x_1, x_2, x_3, x_4, x_5) + l[0] * np.max(
        [0, g_1(x_1, x_2, x_3, x_4, x_5)]
    )
    return fitness


def welded_beam_design(x):
    sigma_max = 30000
    E = 30 * 1e6
    t_max = 13000
    L = 14
    P = 6000
    delta_max = 0.25
    G = 12 * 1e6

    def M(x_2):
        return (L + x_2 / 2) * P

    def R(x_1, x_2, x_3):
        return (x_2**2 / 4 + ((x_1 + x_3) / 2) ** 2) ** 0.5

    def delta(x_3, x_4):
        return 4 * P * L**3 / (E * x_3**3 * x_4)

    def J(x_1, x_2, x_3):
        return (x_2**2 / 12 + ((x_1 + x_3) / 2) ** 2) * x_1 * x_2 * 2 ** (3 / 2)

    def sigma(x_3, x_4):
        return 6 * P * L / (x_4 * x_3**2)

    def P_c(x_3, x_4):
        return (
            4.013
            * E
            * x_4**3
            * x_3
            / (6 * L**2)
            * (1 - x_3 / (2 * L) * (E / (4 * G)) ** 0.5)
        )

    def t_1(x_1, x_2):
        return P / (2**0.5 * x_1 * x_2)

    def t_2(x_1, x_2, x_3):
        return R(x_1, x_2, x_3) * M(x_2) / J(x_1, x_2, x_3)

    def t(x_1, x_2, x_3):
        return (
            t_1(x_1, x_2) ** 2
            + 2 * t_1(x_1, x_2) * t_2(x_1, x_2, x_3) * x_2 / (2 * R(x_1, x_2, x_3))
            + t_2(x_1, x_2, x_3) ** 2
        ) ** 0.5

    def g_1(x_1, x_2, x_3):
        return t(x_1, x_2, x_3) - t_max

    def g_2(x_3, x_4):
        return -sigma_max + sigma(x_3, x_4)

    def g_3(x_1, x_4):
        return x_1 - x_4

    def g_4(x_1, x_2, x_3, x_4):
        return 0.04811 * x_3 * x_4 * (14 + x_2) + 0.10471 * x_1**2 - 5

    def g_5(x_1):
        return -x_1 + 0.125

    def g_6(x_3, x_4):
        return delta(x_3, x_4) - delta_max

    def g_7(x_3, x_4):
        return P - P_c(x_3, x_4)

    def f(x_1, x_2, x_3, x_4):
        return 1.10471 * x_2 * x_1**2 + 0.04811 * x_3 * x_4 * (14 + x_2)

    x = np.clip(
        x,
        np.array([0.1, 0.1, 0.1, 0.1]),
        np.array([2, 10, 10, 2]),
    )
    x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
    l = [1500000, 1500000, 1500000, 1500000, 1500000, 1500000, 1500000]

    fitness = (
        f(x_1, x_2, x_3, x_4)
        + l[0] * np.max([0, g_1(x_1, x_2, x_3)])
        + l[1] * np.max([0, g_2(x_3, x_4)])
        + l[2] * np.max([0, g_3(x_1, x_4)])
        + l[3] * np.max([0, g_4(x_1, x_2, x_3, x_4)])
        + l[4] * np.max([0, g_5(x_1)])
        + l[5] * np.max([0, g_6(x_3, x_4)])
        + l[6] * np.max([0, g_7(x_3, x_4)])
    )
    return fitness


def gear_train_design(x):
    def f(x_1, x_2, x_3, x_4):
        return (1 / 6.931 - x_2 * x_3 / (x_1 * x_4)) ** 2

    x = np.round(np.clip(x, np.array([12, 12, 12, 12]), np.array([60, 60, 60, 60])))
    x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]

    fitness = f(x_1, x_2, x_3, x_4)
    return fitness


def pressure_vessel_optimization(x):
    def g_1(x_1, x_3):
        return -x_1 + 0.0193 * x_3

    def g_2(x_2, x_3):
        return -x_2 + 0.00954 * x_3

    def g_3(x_3, x_4):
        return 1296000 - np.pi * x_3**2 * x_4 - 4 * np.pi / 3 * x_3**3

    def g_4(x_4):
        return x_4 - 240

    def f(x_1, x_2, x_3, x_4):
        return (
            19.84 * x_1**2 * x_3
            + 3.1661 * x_1**2 * x_4
            + 1.7781 * x_2 * x_3**2
            + 0.6224 * x_1 * x_3 * x_4
        )

    x = np.clip(x, np.array([1e-9, 1e-9, 10, 10]), np.array([100, 100, 200, 200]))
    x_1, x_2, x_3, x_4 = x[0], x[1], x[2], x[3]
    l = [1500000, 1500000, 1500000, 1500000]

    fitness = (
        f(x_1, x_2, x_3, x_4)
        + l[0] * np.max([0, g_1(x_1, x_3)])
        + l[1] * np.max([0, g_2(x_2, x_3)])
        + l[2] * np.max([0, g_3(x_3, x_4)])
        + l[3] * np.max([0, g_4(x_4)])
    )
    return fitness


def speed_reducer_optimization(x):
    def g_1(x_1, x_2, x_3):
        return -1 + 27 / (x_1 * x_2**2 * x_3)

    def g_2(x_1, x_2, x_3):
        return -1 + 397.5 / (x_1 * x_2**2 * x_3**2)

    def g_3(x_2, x_3, x_4, x_6):
        return -1 + 1.93 * x_4**3 / (x_2 * x_3 * x_6**4)

    def g_4(x_2, x_3, x_5, x_7):
        return -1 + 1.93 * x_5**3 / (x_2 * x_3 * x_7**4)

    def g_5(x_2, x_3, x_4, x_6):
        return ((745 * x_4 / (x_2 * x_3)) ** 2 + 16.9 * 1e6) ** 0.5 / (110 * x_6**3) - 1

    def g_6(x_2, x_3, x_5, x_7):
        return ((745 * x_5 / (x_2 * x_3)) ** 2 + 157.5 * 1e6) ** 0.5 / (85 * x_7**3) - 1

    def g_7(x_2, x_3):
        return -1 + x_2 * x_3 / 40

    def g_8(x_1, x_2):
        return -1 + 5 * x_2 / x_1

    def g_9(x_1, x_2):
        return -1 + x_1 / (12 * x_2)

    def g_10(x_4, x_6):
        return -1 + (1.5 * x_6 + 1.9) / x_4

    def g_11(x_5, x_7):
        return -1 + (1.1 * x_7 + 1.9) / x_5

    def f(x_1, x_2, x_3, x_4, x_5, x_6, x_7):
        return (
            0.7854 * x_1 * x_2**2 * (3.3333 * x_3**2 + 14.9334 * x_3 - 43.0934)
            - 1.5079 * x_1 * (x_6**2 + x_7**2)
            + 7.4777 * (x_6**3 + x_7**3)
            + 0.7854 * (x_4 * x_6**2 + x_5 * x_7**2)
        )

    x = np.clip(
        x,
        np.array([2.6, 0.7, 17, 7.3, 7.8, 2.9, 5]),
        np.array([3.6, 0.8, 28, 8.3, 8.3, 3.9, 5.5]),
    )
    x_1, x_2, x_3, x_4, x_5, x_6, x_7 = x[0], x[1], x[2], x[3], x[4], x[5], x[6]
    l = [
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
    ]

    fitness = (
        f(x_1, x_2, x_3, x_4, x_5, x_6, x_7)
        + l[0] * np.max([0, g_1(x_1, x_2, x_3)])
        + l[1] * np.max([0, g_2(x_1, x_2, x_3)])
        + l[2] * np.max([0, g_3(x_2, x_3, x_4, x_6)])
        + l[3] * np.max([0, g_4(x_2, x_3, x_5, x_7)])
        + l[4] * np.max([0, g_5(x_2, x_3, x_4, x_6)])
        + l[5] * np.max([0, g_6(x_2, x_3, x_5, x_7)])
        + l[6] * np.max([0, g_7(x_2, x_3)])
        + l[7] * np.max([0, g_8(x_1, x_2)])
        + l[8] * np.max([0, g_9(x_1, x_2)])
        + l[9] * np.max([0, g_10(x_4, x_6)])
        + l[10] * np.max([0, g_11(x_5, x_7)])
    )
    return fitness


def I_beam_vertical_deflection_design(x):
    def g_1(h, b, t_w, t_f):
        return t_w * (h - 2 * t_f) + 2 * b * t_f - 300

    def g_2(h, b, t_w, t_f):
        x_1 = (
            2 * b * t_f * (4 * t_f**2 - 3 * h * (h - 2 * t_f))
            + t_w * (h - 2 * t_f) ** 3
        )
        x_2 = 2 * t_f * b**3 + (h - 2 * t_f) * t_w**3
        return 18 * h * 1e4 / x_1 + 15 * b * 1e3 / x_2

    def f(h, b, t_w, t_f):
        return 5000 / (
            t_w * (h - 2 * t_f) ** 3 / 12
            + b * t_f**3 / 6
            + 2 * b * t_f * (h - t_f) ** 2 / 4
        )

    x = np.clip(x, np.array([10, 10, 0.9, 0.9]), np.array([80, 50, 5, 5]))
    h, b, t_w, t_f = x[0], x[1], x[2], x[3]
    l = [
        1500000,
        1500000,
    ]

    fitness = (
        f(h, b, t_w, t_f)
        + l[0] * np.max([0, g_1(h, b, t_w, t_f)])
        + l[1] * np.max([0, g_2(h, b, t_w, t_f)])
    )
    return fitness


def tubular_column_design(x):
    P, sigma_y, p, L, E = 2500, 500, 0.0025, 250, 8.5 * 1e5

    def g_1(d, t):
        return P / (np.pi * d * t * sigma_y) - 1

    def g_2(d, t):
        return 8 * P / (np.pi**3 * E * d * t * (d**2 + t**2)) - 1

    def g_3(d):
        return 2 / d - 1

    def g_4(d):
        return d / 14 - 1

    def g_5(t):
        return 1 / (5 * t) - 1

    def g_6(t):
        return 5 * t / 4 - 1

    def f(d, t):
        return 9.8 * d * t + 2 * d

    x = np.clip(x, np.array([2, 0.2]), np.array([14, 0.8]))
    d, t = x[0], x[1]

    l = [
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
        1500000,
    ]

    fitness = (
        f(d, t)
        + l[0] * np.max([0, g_1(d, t)])
        + l[1] * np.max([0, g_2(d, t)])
        + l[2] * np.max([0, g_3(d)])
        + l[3] * np.max([0, g_4(d)])
        + l[4] * np.max([0, g_5(t)])
        + l[5] * np.max([0, g_6(t)])
    )
    return fitness
